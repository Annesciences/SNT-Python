#### Please add a code sample or a nbviewer link, copy-pastable if possible

```python
# Your code here

```
#### Problem description

[this should explain **why** the current behavior is a problem and what is the expected output.]

#### Expected Output

#### Output of ``folium.__version__``
