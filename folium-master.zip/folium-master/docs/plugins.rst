:mod:`plugins`
--------------

.. automodule:: folium.plugins
   :members:
   :undoc-members:
   :show-inheritance:
